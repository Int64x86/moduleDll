if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_SetHeader/select.js',
    this,
    {
        loader: loader,
        impersonateLoader: impersonateLoader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
