if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_WebsocketRecv/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
