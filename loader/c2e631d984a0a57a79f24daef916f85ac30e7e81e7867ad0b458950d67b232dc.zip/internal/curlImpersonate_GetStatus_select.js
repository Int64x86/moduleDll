if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_GetStatus/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
