if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_Proxy/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
