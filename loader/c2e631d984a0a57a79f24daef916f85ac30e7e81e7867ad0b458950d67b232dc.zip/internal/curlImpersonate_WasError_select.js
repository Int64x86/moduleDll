if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_WasError/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
