if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_ClearHeaders/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
