if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_ClientId/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
