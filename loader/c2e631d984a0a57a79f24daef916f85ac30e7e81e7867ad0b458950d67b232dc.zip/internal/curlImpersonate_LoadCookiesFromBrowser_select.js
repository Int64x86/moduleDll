if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_LoadCookiesFromBrowser/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
