<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_CheckUpdates/interface.js',
    arguments[0]
) %>
