if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_SaveCookies/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
