if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_GetHeaders/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
