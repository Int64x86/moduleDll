if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_Reset/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
