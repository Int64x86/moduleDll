if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_GetHeader/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
