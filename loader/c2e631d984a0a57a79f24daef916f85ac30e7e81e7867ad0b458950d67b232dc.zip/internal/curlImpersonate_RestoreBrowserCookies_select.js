if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_RestoreBrowserCookies/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
