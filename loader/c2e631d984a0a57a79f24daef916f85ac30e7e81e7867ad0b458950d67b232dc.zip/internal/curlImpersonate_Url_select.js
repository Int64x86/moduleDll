if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_Url/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
