<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_RestoreCookies/interface.js',
    arguments[0]
) %>
