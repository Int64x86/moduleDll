<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Settings/interface.js',
    arguments[0]
) %>
