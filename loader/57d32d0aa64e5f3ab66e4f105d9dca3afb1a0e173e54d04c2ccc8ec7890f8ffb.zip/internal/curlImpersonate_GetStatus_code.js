<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_GetStatus/code.js',
    arguments[0]
) %>
