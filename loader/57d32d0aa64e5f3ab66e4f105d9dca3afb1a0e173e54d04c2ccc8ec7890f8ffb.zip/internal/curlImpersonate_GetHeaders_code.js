<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_GetHeaders/code.js',
    arguments[0]
) %>
