<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_GetStatus/interface.js',
    arguments[0]
) %>
