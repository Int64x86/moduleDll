<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_GetHeaders/interface.js',
    arguments[0]
) %>
