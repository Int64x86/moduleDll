<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Post/interface.js',
    arguments[0]
) %>
