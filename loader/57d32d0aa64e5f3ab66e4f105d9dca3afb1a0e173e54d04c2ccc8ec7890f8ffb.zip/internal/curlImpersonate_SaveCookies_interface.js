<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_SaveCookies/interface.js',
    arguments[0]
) %>
