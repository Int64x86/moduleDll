<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_SaveCookies/code.js',
    arguments[0]
) %>
