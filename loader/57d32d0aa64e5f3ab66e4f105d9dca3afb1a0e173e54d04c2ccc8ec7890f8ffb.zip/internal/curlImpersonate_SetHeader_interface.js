<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_SetHeader/interface.js',
    arguments[0]
) %>
