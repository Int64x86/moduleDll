<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Crypt/interface.js',
    arguments[0]
) %>
