<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Url/interface.js',
    arguments[0]
) %>
