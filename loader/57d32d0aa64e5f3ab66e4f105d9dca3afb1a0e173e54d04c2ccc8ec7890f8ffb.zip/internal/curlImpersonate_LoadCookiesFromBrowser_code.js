<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_LoadCookiesFromBrowser/code.js',
    arguments[0]
) %>
