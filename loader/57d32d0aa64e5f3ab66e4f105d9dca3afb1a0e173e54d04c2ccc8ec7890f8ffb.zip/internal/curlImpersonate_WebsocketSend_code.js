<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_WebsocketSend/code.js',
    arguments[0]
) %>
