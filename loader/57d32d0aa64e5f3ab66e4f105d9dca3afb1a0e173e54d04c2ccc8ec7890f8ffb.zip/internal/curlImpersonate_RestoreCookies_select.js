if (ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_RestoreCookies/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
) === false) return;
