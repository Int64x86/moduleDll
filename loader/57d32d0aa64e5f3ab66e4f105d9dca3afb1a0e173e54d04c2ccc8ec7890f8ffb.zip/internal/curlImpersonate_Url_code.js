<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Url/code.js',
    arguments[0]
) %>
