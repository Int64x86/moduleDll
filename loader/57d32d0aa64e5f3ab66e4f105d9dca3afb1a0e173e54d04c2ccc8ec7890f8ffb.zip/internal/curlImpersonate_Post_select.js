if (ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_Post/select.js',
    this,
    {
        loader: loader,
        impersonateLoader: impersonateLoader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
) === false) return;
