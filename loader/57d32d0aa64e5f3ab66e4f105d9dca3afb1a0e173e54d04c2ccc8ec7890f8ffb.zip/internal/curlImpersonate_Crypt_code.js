<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Crypt/code.js',
    arguments[0]
) %>
