<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_WebsocketRecv/interface.js',
    arguments[0]
) %>
