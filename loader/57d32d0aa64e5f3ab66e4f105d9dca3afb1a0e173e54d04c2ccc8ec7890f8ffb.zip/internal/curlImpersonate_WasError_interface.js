<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_WasError/interface.js',
    arguments[0]
) %>
