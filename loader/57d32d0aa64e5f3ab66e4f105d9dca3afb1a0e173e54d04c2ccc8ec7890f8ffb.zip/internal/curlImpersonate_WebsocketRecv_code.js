<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_WebsocketRecv/code.js',
    arguments[0]
) %>
