<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Get/interface.js',
    arguments[0]
) %>
