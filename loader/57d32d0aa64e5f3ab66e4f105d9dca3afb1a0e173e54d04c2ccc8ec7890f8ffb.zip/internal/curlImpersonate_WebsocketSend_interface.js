<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_WebsocketSend/interface.js',
    arguments[0]
) %>
