<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_ClientId/code.js',
    arguments[0]
) %>
