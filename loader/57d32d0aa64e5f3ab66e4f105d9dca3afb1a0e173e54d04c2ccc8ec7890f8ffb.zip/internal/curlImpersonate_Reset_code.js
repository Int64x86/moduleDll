<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Reset/code.js',
    arguments[0]
) %>
