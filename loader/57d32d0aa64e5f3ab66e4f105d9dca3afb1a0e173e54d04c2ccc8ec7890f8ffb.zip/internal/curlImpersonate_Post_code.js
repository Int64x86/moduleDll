<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Post/code.js',
    arguments[0]
) %>
