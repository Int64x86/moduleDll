<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Reset/interface.js',
    arguments[0]
) %>
