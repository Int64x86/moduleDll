<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_GetHeader/interface.js',
    arguments[0]
) %>
