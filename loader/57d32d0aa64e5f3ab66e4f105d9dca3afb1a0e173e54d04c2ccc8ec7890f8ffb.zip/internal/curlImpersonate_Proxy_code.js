<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Proxy/code.js',
    arguments[0]
) %>
