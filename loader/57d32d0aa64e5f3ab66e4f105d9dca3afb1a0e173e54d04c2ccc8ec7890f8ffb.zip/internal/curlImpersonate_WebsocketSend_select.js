if (ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_WebsocketSend/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
) === false) return;
