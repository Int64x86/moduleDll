<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Error/interface.js',
    arguments[0]
) %>
