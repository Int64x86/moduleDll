<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_ClearHeaders/interface.js',
    arguments[0]
) %>
