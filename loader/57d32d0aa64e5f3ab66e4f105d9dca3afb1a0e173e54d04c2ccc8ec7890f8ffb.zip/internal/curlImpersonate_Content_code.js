<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Content/code.js',
    arguments[0]
) %>
