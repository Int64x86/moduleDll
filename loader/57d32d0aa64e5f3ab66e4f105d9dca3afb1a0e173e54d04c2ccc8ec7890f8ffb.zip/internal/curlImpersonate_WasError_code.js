<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_WasError/code.js',
    arguments[0]
) %>
