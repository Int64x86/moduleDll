<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Proxy/interface.js',
    arguments[0]
) %>
