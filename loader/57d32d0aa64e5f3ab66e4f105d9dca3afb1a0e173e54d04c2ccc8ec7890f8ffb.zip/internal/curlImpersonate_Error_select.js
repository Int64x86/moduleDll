if (ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_Error/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
) === false) return;
