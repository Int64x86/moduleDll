if (ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_Crypt/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
) === false) return;
