<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_RestoreBrowserCookies/code.js',
    arguments[0]
) %>
