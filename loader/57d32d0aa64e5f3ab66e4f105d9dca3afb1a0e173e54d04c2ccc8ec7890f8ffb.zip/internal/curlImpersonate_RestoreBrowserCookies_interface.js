<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_RestoreBrowserCookies/interface.js',
    arguments[0]
) %>
