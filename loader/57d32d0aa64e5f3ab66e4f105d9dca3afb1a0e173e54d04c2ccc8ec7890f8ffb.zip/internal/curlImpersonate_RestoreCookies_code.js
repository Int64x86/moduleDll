<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_RestoreCookies/code.js',
    arguments[0]
) %>
