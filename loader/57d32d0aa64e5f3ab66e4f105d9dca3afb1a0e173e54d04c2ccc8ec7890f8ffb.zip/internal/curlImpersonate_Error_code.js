<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Error/code.js',
    arguments[0]
) %>
