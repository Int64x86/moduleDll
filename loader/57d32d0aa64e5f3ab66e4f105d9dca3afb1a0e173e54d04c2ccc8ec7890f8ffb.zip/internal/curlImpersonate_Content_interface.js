<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Content/interface.js',
    arguments[0]
) %>
