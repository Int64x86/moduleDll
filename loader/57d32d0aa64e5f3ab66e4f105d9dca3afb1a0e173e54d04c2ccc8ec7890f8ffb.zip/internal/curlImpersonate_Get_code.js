<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Get/code.js',
    arguments[0]
) %>
