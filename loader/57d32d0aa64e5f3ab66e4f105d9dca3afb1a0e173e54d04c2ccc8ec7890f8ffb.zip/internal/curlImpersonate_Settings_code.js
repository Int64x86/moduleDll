<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Settings/code.js',
    arguments[0]
) %>
