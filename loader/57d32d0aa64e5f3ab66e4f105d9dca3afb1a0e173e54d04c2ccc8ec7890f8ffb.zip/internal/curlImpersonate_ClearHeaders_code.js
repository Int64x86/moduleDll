<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_ClearHeaders/code.js',
    arguments[0]
) %>
