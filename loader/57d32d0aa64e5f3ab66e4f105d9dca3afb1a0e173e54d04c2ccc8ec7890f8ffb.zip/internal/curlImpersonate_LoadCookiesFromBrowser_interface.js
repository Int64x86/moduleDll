<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_LoadCookiesFromBrowser/interface.js',
    arguments[0]
) %>
