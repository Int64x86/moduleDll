<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_SetHeader/code.js',
    arguments[0]
) %>
