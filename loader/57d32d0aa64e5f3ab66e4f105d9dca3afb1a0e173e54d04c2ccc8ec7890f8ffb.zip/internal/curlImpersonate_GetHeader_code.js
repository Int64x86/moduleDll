<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_GetHeader/code.js',
    arguments[0]
) %>
