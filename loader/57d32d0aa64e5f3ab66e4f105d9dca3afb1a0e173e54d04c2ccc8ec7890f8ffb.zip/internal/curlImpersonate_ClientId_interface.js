<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_ClientId/interface.js',
    arguments[0]
) %>
