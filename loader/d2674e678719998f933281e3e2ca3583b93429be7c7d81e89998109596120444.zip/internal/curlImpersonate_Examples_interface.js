<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_Examples/interface.js',
    arguments[0]
) %>
