(function () {
	var result = JSON.parse(native("impersonate", "sync_call", JSON.stringify({"action": "get_engine_source"})))
	if (result.success) {
		eval(_preprocess(result.source))
	} else {
		impersonateError = result.error;
		log_fail(impersonateError);
	}
})()
