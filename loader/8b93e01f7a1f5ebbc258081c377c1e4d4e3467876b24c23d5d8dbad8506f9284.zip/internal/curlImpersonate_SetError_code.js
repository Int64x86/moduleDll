<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_SetError/code.js',
    arguments[0]
) %>
