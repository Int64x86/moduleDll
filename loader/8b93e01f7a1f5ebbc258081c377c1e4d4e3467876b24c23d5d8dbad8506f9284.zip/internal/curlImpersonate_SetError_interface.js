<%= ImpersonateInternal.render(
    '/res/internal/actions/curlImpersonate_SetError/interface.js',
    arguments[0]
) %>
