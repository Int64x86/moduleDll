if (!ImpersonateInternal.runSelect(
    '/res/internal/actions/curlImpersonate_SetError/select.js',
    this,
    {
        loader: loader,
        action: action,
        DisableIfAdd: DisableIfAdd
    }
)) return;
